# FieldLogger — اپلیکیشن ثبت میدانی عکس

## امکانات
- 📷 دوربین با CameraX (دوربین پشت)
- 📍 موقعیت GPS خودکار (X=Lat, Y=Lng)
- 📅 تاریخ شمسی (هجری شمسی) + ساعت
- 📁 فولدربندی عکس‌ها
- 🔍 جستجو در توضیحات
- 🏷 فیلتر بر اساس فیدر
- 🗄 پایگاه داده Room (SQLite)

## صفحه جزئیات (به ترتیب)
1. توضیحات
2. فیدر
3. موقعیت X , Y
4. تاریخ عکس

---

## پیش‌نیازها برای Build

- **Android Studio** (Hedgehog یا جدیدتر) — [دانلود](https://developer.android.com/studio)
- **JDK 17+** (با Android Studio همراه است)
- اینترنت برای دانلود dependencies اولیه

---

## روش Build

### روش ۱ — Android Studio (توصیه‌شده)

```
1. Android Studio را باز کن
2. File > Open > پوشه FieldLogger را انتخاب کن
3. صبر کن Gradle sync تمام شود (~2-5 دقیقه)
4. Build > Build Bundle(s)/APK(s) > Build APK(s)
5. APK در:  app/build/outputs/apk/debug/app-debug.apk
```

### روش ۲ — Command Line

```bash
# Linux / Mac
chmod +x gradlew
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

APK خروجی: `app/build/outputs/apk/debug/app-debug.apk`

---

## نصب روی گوشی

```bash
# از طریق ADB
adb install app/build/outputs/apk/debug/app-debug.apk

# یا فایل APK را مستقیماً به گوشی انتقال بده و نصب کن
# (باید "نصب از منابع ناشناس" در تنظیمات فعال باشد)
```

---

## مجوزهای اپلیکیشن

| مجوز | کاربرد |
|------|---------|
| CAMERA | گرفتن عکس |
| ACCESS_FINE_LOCATION | موقعیت دقیق GPS |
| ACCESS_COARSE_LOCATION | موقعیت تقریبی |
| READ_MEDIA_IMAGES | خواندن تصاویر (Android 13+) |
| READ/WRITE_EXTERNAL_STORAGE | ذخیره‌سازی (Android 9 و پایین‌تر) |

---

## ساختار پروژه

```
FieldLogger/
├── app/src/main/
│   ├── java/com/fieldlogger/
│   │   ├── Database.kt          ← Room DB + Entity + DAO
│   │   ├── JalaliCalendar.kt    ← تبدیل تاریخ شمسی
│   │   ├── PhotoViewModel.kt    ← ViewModel + StateFlow
│   │   ├── MainActivity.kt      ← گالری + سرچ + فیلتر
│   │   ├── CameraActivity.kt    ← دوربین + GPS
│   │   ├── PhotoDetailActivity.kt ← جزئیات + ویرایش
│   │   └── PhotoAdapter.kt      ← RecyclerView adapter
│   ├── res/layout/
│   │   ├── activity_main.xml
│   │   ├── activity_camera.xml
│   │   ├── activity_photo_detail.xml
│   │   ├── item_photo.xml
│   │   └── item_folder.xml
│   └── AndroidManifest.xml
├── build.gradle
└── settings.gradle
```

---

## نکات

- عکس‌ها در حافظه داخلی اپلیکیشن ذخیره می‌شوند (`/data/data/com.fieldlogger/files/photos/`)
- برای backup عکس‌ها می‌توان از `adb backup` استفاده کرد
- minSdk = 26 (Android 8.0+)
