package com.fieldlogger

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fieldlogger.databinding.ActivityMainBinding
import com.google.android.material.chip.Chip
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var vm: PhotoViewModel
    private lateinit var adapter: PhotoAdapter

    // درخواست مجوزها
    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants.values.all { it }) openCamera()
        else Toast.makeText(this, "برای استفاده از دوربین مجوز لازم است", Toast.LENGTH_LONG).show()
    }

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { /* عکس از طریق Room reload می‌شه */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        vm = ViewModelProvider(this)[PhotoViewModel::class.java]

        setupTabs()
        setupGallery()
        setupSearch()
        setupFab()
        observeData()
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> { // همه
                        vm.selectedFolder.value = ""
                        binding.recyclerView.layoutManager = GridLayoutManager(this@MainActivity, 2)
                        adapter.setMode(PhotoAdapter.MODE_GRID)
                    }
                    1 -> { // پوشه‌ها
                        vm.selectedFolder.value = "__folders__"
                        binding.recyclerView.layoutManager = LinearLayoutManager(this@MainActivity)
                        adapter.setMode(PhotoAdapter.MODE_FOLDER)
                    }
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupGallery() {
        adapter = PhotoAdapter(
            onPhotoClick = { photo ->
                val i = Intent(this, PhotoDetailActivity::class.java)
                i.putExtra("photo_id", photo.id)
                startActivity(i)
            },
            onFolderClick = { folder ->
                vm.selectedFolder.value = folder
                binding.tabLayout.getTabAt(0)?.select()
                binding.folderChip.text = folder
                binding.folderChip.visibility = View.VISIBLE
            }
        )
        binding.recyclerView.layoutManager = GridLayoutManager(this, 2)
        binding.recyclerView.adapter = adapter

        // chip حذف فیلتر پوشه
        binding.folderChip.setOnCloseIconClickListener {
            vm.selectedFolder.value = ""
            binding.folderChip.visibility = View.GONE
        }
    }

    private fun setupSearch() {
        binding.searchEdit.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { vm.searchQuery.value = s.toString() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
    }

    private fun setupFab() {
        binding.fabCamera.setOnClickListener { checkAndOpenCamera() }
        // دکمه پوشه جدید
        binding.btnNewFolder.setOnClickListener { showNewFolderDialog() }
    }

    private fun observeData() {
        lifecycleScope.launch {
            vm.photos.collect { photos ->
                if (vm.selectedFolder.value == "__folders__") {
                    // نمایش پوشه‌ها
                } else {
                    adapter.submitPhotos(photos)
                    binding.emptyView.visibility = if (photos.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
        lifecycleScope.launch {
            vm.feeders.collect { feeders -> updateFeederChips(feeders) }
        }
        lifecycleScope.launch {
            vm.folders.collect { folders ->
                if (vm.selectedFolder.value == "__folders__") {
                    adapter.submitFolders(folders, vm.photos.value)
                }
            }
        }
    }

    private fun updateFeederChips(feeders: List<String>) {
        binding.feederChipGroup.removeAllViews()
        // chip "همه"
        val all = Chip(this).apply {
            text = "همه"
            isCheckable = true
            isChecked = vm.selectedFeeder.value.isEmpty()
            setOnCheckedChangeListener { _, checked -> if (checked) vm.selectedFeeder.value = "" }
        }
        binding.feederChipGroup.addView(all)
        feeders.forEach { feeder ->
            val c = Chip(this).apply {
                text = feeder
                isCheckable = true
                isChecked = vm.selectedFeeder.value == feeder
                setOnCheckedChangeListener { _, checked ->
                    if (checked) vm.selectedFeeder.value = feeder
                }
            }
            binding.feederChipGroup.addView(c)
        }
    }

    private fun checkAndOpenCamera() {
        val perms = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P)
            perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)

        val denied = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (denied.isEmpty()) openCamera()
        else permLauncher.launch(denied.toTypedArray())
    }

    private fun openCamera() {
        cameraLauncher.launch(Intent(this, CameraActivity::class.java))
    }

    private fun showNewFolderDialog() {
        val edit = EditText(this).apply { hint = "نام پوشه"; textAlignment = View.TEXT_ALIGNMENT_VIEW_START }
        AlertDialog.Builder(this)
            .setTitle("پوشه جدید")
            .setView(edit)
            .setPositiveButton("ایجاد") { _, _ ->
                val name = edit.text.toString().trim()
                if (name.isNotEmpty()) {
                    // ذخیره پوشه — یک عکس placeholder نیاز نیست، پوشه‌ها از DB استخراج می‌شن
                    Toast.makeText(this, "پوشه «$name» آماده است", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }
}
