package com.fieldlogger

import android.app.Application
import androidx.lifecycle.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PhotoViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).photoDao()

    val searchQuery = MutableStateFlow("")
    val selectedFolder = MutableStateFlow("")
    val selectedFeeder = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val photos: StateFlow<List<Photo>> = combine(searchQuery, selectedFolder, selectedFeeder) {
        q, folder, feeder -> Triple(q, folder, feeder)
    }.flatMapLatest { (q, folder, feeder) ->
        dao.filter(folder, feeder, q)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val feeders: StateFlow<List<String>> = dao.getFeeders()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val folders: StateFlow<List<String>> = dao.getFolders()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun insert(photo: Photo, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = dao.insert(photo)
        onDone(id)
    }

    fun update(photo: Photo) = viewModelScope.launch { dao.update(photo) }

    fun delete(photo: Photo) = viewModelScope.launch { dao.delete(photo) }

    suspend fun getById(id: Long) = dao.getById(id)
}
