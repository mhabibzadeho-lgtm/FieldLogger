package com.fieldlogger

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ─── Entity ───────────────────────────────────────────────────────────────────
@Entity(tableName = "photos")
data class Photo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val imagePath: String,
    val description: String = "",
    val feeder: String = "",
    val folder: String = "عمومی",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val jalaliDate: String = "",   // e.g. ۱۴۰۳/۰۳/۱۲
    val timeStr: String = "",      // e.g. ۱۴:۳۵
    val createdAt: Long = System.currentTimeMillis()
)

// ─── DAO ──────────────────────────────────────────────────────────────────────
@Dao
interface PhotoDao {
    @Query("SELECT * FROM photos ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Photo>>

    @Query("SELECT * FROM photos WHERE folder = :folder ORDER BY createdAt DESC")
    fun getByFolder(folder: String): Flow<List<Photo>>

    @Query("SELECT * FROM photos WHERE description LIKE '%' || :q || '%' ORDER BY createdAt DESC")
    fun search(q: String): Flow<List<Photo>>

    @Query("SELECT * FROM photos WHERE feeder = :feeder ORDER BY createdAt DESC")
    fun getByFeeder(feeder: String): Flow<List<Photo>>

    @Query("""SELECT * FROM photos WHERE
        (:folder = '' OR folder = :folder) AND
        (:feeder = '' OR feeder = :feeder) AND
        (:query = '' OR description LIKE '%' || :query || '%')
        ORDER BY createdAt DESC""")
    fun filter(folder: String, feeder: String, query: String): Flow<List<Photo>>

    @Query("SELECT DISTINCT feeder FROM photos WHERE feeder != '' ORDER BY feeder")
    fun getFeeders(): Flow<List<String>>

    @Query("SELECT DISTINCT folder FROM photos ORDER BY folder")
    fun getFolders(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(photo: Photo): Long

    @Update
    suspend fun update(photo: Photo)

    @Delete
    suspend fun delete(photo: Photo)

    @Query("SELECT * FROM photos WHERE id = :id")
    suspend fun getById(id: Long): Photo?
}

// ─── Database ─────────────────────────────────────────────────────────────────
@Database(entities = [Photo::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun photoDao(): PhotoDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(context: android.content.Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "fieldlogger.db")
                    .build().also { INSTANCE = it }
            }
    }
}
