package com.fieldlogger

import android.annotation.SuppressLint
import android.content.Intent
import android.location.Location
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.fieldlogger.databinding.ActivityCameraBinding
import com.google.android.gms.location.*
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCameraBinding
    private lateinit var vm: PhotoViewModel
    private lateinit var executor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var currentLocation: Location? = null
    private lateinit var fusedClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        vm = ViewModelProvider(this)[PhotoViewModel::class.java]
        executor = Executors.newSingleThreadExecutor()
        fusedClient = LocationServices.getFusedLocationProviderClient(this)

        updateDateTime()
        startCamera()
        getLocation()

        binding.shutterBtn.setOnClickListener { takePhoto() }
        binding.btnBack.setOnClickListener { finish() }
    }

    private fun updateDateTime() {
        binding.tvDate.text = JalaliCalendar.toPersianNumerals(JalaliCalendar.nowJalali())
        binding.tvTime.text = JalaliCalendar.toPersianNumerals(JalaliCalendar.nowTime())
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            } catch (e: Exception) {
                Log.e("CameraActivity", "Camera bind error", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @SuppressLint("MissingPermission")
    private fun getLocation() {
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000).build()
        fusedClient.requestLocationUpdates(req, object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                currentLocation = result.lastLocation
                result.lastLocation?.let { loc ->
                    val lat = "%.6f".format(loc.latitude)
                    val lng = "%.6f".format(loc.longitude)
                    binding.tvLocation.text = "X: $lat\nY: $lng"
                }
                fusedClient.removeLocationUpdates(this)
            }
        }, Looper.getMainLooper())

        // سریع‌تر: آخرین موقعیت ذخیره‌شده
        fusedClient.lastLocation.addOnSuccessListener { loc ->
            if (loc != null && currentLocation == null) {
                currentLocation = loc
                val lat = "%.6f".format(loc.latitude)
                val lng = "%.6f".format(loc.longitude)
                binding.tvLocation.text = "X: $lat\nY: $lng"
            }
        }
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        binding.shutterBtn.isEnabled = false

        val dir = File(filesDir, "photos").also { it.mkdirs() }
        val file = File(dir, "${System.currentTimeMillis()}.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(file).build()

        capture.takePicture(output, executor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(results: ImageCapture.OutputFileResults) {
                val jalaliDate = JalaliCalendar.nowJalali()
                val time = JalaliCalendar.nowTime()
                val lat = currentLocation?.latitude ?: 0.0
                val lng = currentLocation?.longitude ?: 0.0

                // انتقال به صفحه جزئیات برای وارد کردن توضیحات
                val intent = Intent(this@CameraActivity, PhotoDetailActivity::class.java).apply {
                    putExtra("new_photo_path", file.absolutePath)
                    putExtra("jalali_date", jalaliDate)
                    putExtra("time_str", time)
                    putExtra("latitude", lat)
                    putExtra("longitude", lng)
                }
                runOnUiThread {
                    startActivity(intent)
                    finish()
                }
            }

            override fun onError(e: ImageCaptureException) {
                runOnUiThread {
                    Toast.makeText(this@CameraActivity, "خطا در گرفتن عکس", Toast.LENGTH_SHORT).show()
                    binding.shutterBtn.isEnabled = true
                }
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
        fusedClient.removeLocationUpdates(object : LocationCallback() {})
    }
}
