package com.fieldlogger

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.fieldlogger.databinding.ActivityPhotoDetailBinding
import kotlinx.coroutines.launch
import java.io.File

class PhotoDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPhotoDetailBinding
    private lateinit var vm: PhotoViewModel
    private var currentPhoto: Photo? = null
    private var isNewPhoto = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhotoDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        vm = ViewModelProvider(this)[PhotoViewModel::class.java]

        val photoId = intent.getLongExtra("photo_id", -1L)
        val newPath = intent.getStringExtra("new_photo_path")

        if (newPath != null) {
            // عکس جدید از دوربین
            isNewPhoto = true
            val photo = Photo(
                imagePath = newPath,
                jalaliDate = intent.getStringExtra("jalali_date") ?: JalaliCalendar.nowJalali(),
                timeStr = intent.getStringExtra("time_str") ?: JalaliCalendar.nowTime(),
                latitude = intent.getDoubleExtra("latitude", 0.0),
                longitude = intent.getDoubleExtra("longitude", 0.0)
            )
            currentPhoto = photo
            displayPhoto(photo)
            setEditing(true)
        } else if (photoId != -1L) {
            lifecycleScope.launch {
                val photo = vm.getById(photoId)
                if (photo != null) {
                    currentPhoto = photo
                    runOnUiThread { displayPhoto(photo); setEditing(false) }
                }
            }
        }

        setupButtons()
        loadFolders()
    }

    private fun displayPhoto(photo: Photo) {
        Glide.with(this).load(File(photo.imagePath)).into(binding.ivPhoto)

        // ۱. توضیحات
        binding.etDescription.setText(photo.description)

        // ۲. فیدر
        binding.etFeeder.setText(photo.feeder)

        // ۳. موقعیت X,Y
        binding.tvCoords.text = "X: %.6f\nY: %.6f".format(photo.latitude, photo.longitude)

        // ۴. تاریخ
        val dateDisplay = JalaliCalendar.toPersianNumerals(photo.jalaliDate)
        val timeDisplay = JalaliCalendar.toPersianNumerals(photo.timeStr)
        binding.tvDateTime.text = "$dateDisplay  —  $timeDisplay"

        // پوشه
        binding.tvFolder.text = photo.folder
    }

    private fun setEditing(editing: Boolean) {
        binding.etDescription.isEnabled = editing
        binding.etFeeder.isEnabled = editing
        binding.spinnerFolder.visibility = if (editing) View.VISIBLE else View.GONE
        binding.tvFolder.visibility = if (editing) View.GONE else View.VISIBLE
        binding.btnSave.visibility = if (editing) View.VISIBLE else View.GONE
        binding.btnEdit.visibility = if (editing) View.GONE else View.VISIBLE
        binding.btnDelete.visibility = if (isNewPhoto || editing) View.GONE else View.VISIBLE
    }

    private fun setupButtons() {
        binding.btnBack.setOnClickListener { finish() }

        binding.btnEdit.setOnClickListener { setEditing(true) }

        binding.btnSave.setOnClickListener { savePhoto() }

        binding.btnDelete.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("حذف عکس")
                .setMessage("این عکس حذف شود؟")
                .setPositiveButton("حذف") { _, _ ->
                    currentPhoto?.let { photo ->
                        vm.delete(photo)
                        File(photo.imagePath).delete()
                        finish()
                    }
                }
                .setNegativeButton("انصراف", null)
                .show()
        }
    }

    private fun loadFolders() {
        lifecycleScope.launch {
            vm.folders.collect { folders ->
                val list = if (folders.isEmpty()) listOf("عمومی") else folders
                val adapter = ArrayAdapter(
                    this@PhotoDetailActivity,
                    android.R.layout.simple_spinner_item,
                    list
                ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
                runOnUiThread {
                    binding.spinnerFolder.adapter = adapter
                    currentPhoto?.folder?.let { folder ->
                        val idx = list.indexOf(folder)
                        if (idx >= 0) binding.spinnerFolder.setSelection(idx)
                    }
                }
            }
        }
    }

    private fun savePhoto() {
        val photo = currentPhoto ?: return
        val selectedFolder = binding.spinnerFolder.selectedItem?.toString() ?: "عمومی"
        val updated = photo.copy(
            description = binding.etDescription.text.toString().trim(),
            feeder = binding.etFeeder.text.toString().trim(),
            folder = selectedFolder
        )
        if (isNewPhoto) {
            vm.insert(updated) { id ->
                currentPhoto = updated.copy(id = id)
                isNewPhoto = false
                runOnUiThread {
                    Toast.makeText(this, "عکس ذخیره شد", Toast.LENGTH_SHORT).show()
                    setEditing(false)
                    displayPhoto(currentPhoto!!)
                }
            }
        } else {
            vm.update(updated)
            currentPhoto = updated
            Toast.makeText(this, "تغییرات ذخیره شد", Toast.LENGTH_SHORT).show()
            setEditing(false)
            displayPhoto(updated)
        }
    }
}
