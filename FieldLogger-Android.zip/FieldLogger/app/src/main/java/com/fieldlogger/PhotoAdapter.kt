package com.fieldlogger

import android.view.*
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.io.File

class PhotoAdapter(
    private val onPhotoClick: (Photo) -> Unit,
    private val onFolderClick: (String) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val MODE_GRID = 0
        const val MODE_FOLDER = 1
        const val TYPE_PHOTO = 0
        const val TYPE_FOLDER = 1
    }

    private var mode = MODE_GRID
    private var photos: List<Photo> = emptyList()
    private var folders: List<Pair<String, Int>> = emptyList() // name to count

    fun setMode(m: Int) { mode = m; notifyDataSetChanged() }

    fun submitPhotos(list: List<Photo>) {
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = photos.size
            override fun getNewListSize() = list.size
            override fun areItemsTheSame(o: Int, n: Int) = photos[o].id == list[n].id
            override fun areContentsTheSame(o: Int, n: Int) = photos[o] == list[n]
        })
        photos = list
        diff.dispatchUpdatesTo(this)
    }

    fun submitFolders(names: List<String>, allPhotos: List<Photo>) {
        folders = names.map { name -> name to allPhotos.count { it.folder == name } }
        notifyDataSetChanged()
    }

    override fun getItemViewType(pos: Int) = if (mode == MODE_FOLDER) TYPE_FOLDER else TYPE_PHOTO
    override fun getItemCount() = if (mode == MODE_FOLDER) folders.size else photos.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_FOLDER)
            FolderVH(inflater.inflate(R.layout.item_folder, parent, false))
        else
            PhotoVH(inflater.inflate(R.layout.item_photo, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, pos: Int) {
        if (holder is PhotoVH) holder.bind(photos[pos])
        else if (holder is FolderVH) holder.bind(folders[pos].first, folders[pos].second)
    }

    inner class PhotoVH(v: View) : RecyclerView.ViewHolder(v) {
        private val img = v.findViewById<ImageView>(R.id.ivThumb)
        private val tvFeeder = v.findViewById<TextView>(R.id.tvFeeder)
        private val tvDate = v.findViewById<TextView>(R.id.tvDate)
        private val tvDesc = v.findViewById<TextView>(R.id.tvDesc)

        fun bind(p: Photo) {
            Glide.with(img).load(File(p.imagePath)).centerCrop().into(img)
            tvFeeder.text = p.feeder
            tvFeeder.visibility = if (p.feeder.isBlank()) View.GONE else View.VISIBLE
            tvDate.text = JalaliCalendar.toPersianNumerals(p.jalaliDate)
            tvDesc.text = p.description
            tvDesc.visibility = if (p.description.isBlank()) View.GONE else View.VISIBLE
            itemView.setOnClickListener { onPhotoClick(p) }
        }
    }

    inner class FolderVH(v: View) : RecyclerView.ViewHolder(v) {
        private val tvName = v.findViewById<TextView>(R.id.tvFolderName)
        private val tvCount = v.findViewById<TextView>(R.id.tvPhotoCount)

        fun bind(name: String, count: Int) {
            tvName.text = name
            tvCount.text = "$count عکس"
            itemView.setOnClickListener { onFolderClick(name) }
        }
    }
}
