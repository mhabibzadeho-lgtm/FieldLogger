package com.fieldlogger

import java.util.Calendar

object JalaliCalendar {

    fun toJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gDaysInMonth = intArrayOf(31, 28 + if (gy % 4 == 0 && gy % 100 != 0 || gy % 400 == 0) 1 else 0,
            31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var jy = if (gy <= 1600) 0 else 979
        var gy2 = gy - if (gy <= 1600) 621 else 1600
        val gy3 = if (gm > 2) gy2 + 1 else gy2
        var gDayNo = 365 * gy2 + (gy3 + 3) / 4 - (gy3 + 99) / 100 + (gy3 + 399) / 400
        for (i in 0 until gm - 1) gDayNo += gDaysInMonth[i]
        gDayNo += gd - 1
        var jDayNo = gDayNo - 79
        val jNp = jDayNo / 12053; jDayNo %= 12053
        jy += 33 * jNp + 4 * (jDayNo / 1461)
        jDayNo %= 1461
        if (jDayNo >= 366) { jy += (jDayNo - 1) / 365; jDayNo = (jDayNo - 1) % 365 }
        val jDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)
        var jm = 0
        for (i in 0..11) {
            if (jDayNo >= jDaysInMonth[i]) { jDayNo -= jDaysInMonth[i]; jm++ } else break
        }
        return Triple(jy, jm + 1, jDayNo + 1)
    }

    fun nowJalali(): String {
        val c = Calendar.getInstance()
        val (jy, jm, jd) = toJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return "%04d/%02d/%02d".format(jy, jm, jd)
    }

    fun nowTime(): String {
        val c = Calendar.getInstance()
        return "%02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    // تبدیل اعداد لاتین به فارسی
    fun toPersianNumerals(s: String): String {
        val map = mapOf('0' to '۰','1' to '۱','2' to '۲','3' to '۳','4' to '۴',
            '5' to '۵','6' to '۶','7' to '۷','8' to '۸','9' to '۹')
        return s.map { map[it] ?: it }.joinToString("")
    }
}
